function Z = zhexian(x,y,z)
%x目标对照组的值，一个向量
%y当前对照组的值，一个向量
%z当前实验组的值，一个向量
beishu = x./y;
Z = z.*beishu;
end

