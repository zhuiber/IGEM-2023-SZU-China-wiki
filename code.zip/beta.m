function beta = beta(T,H,S)
%BETA 此处显示有关此函数的摘要
%   此处显示详细说明

beta = S(1)* 1/(sqrt(2*pi)*S(2)).*exp(-(T-20).^2./(2*S(2).^2)).* ...
    1/(sqrt(2*pi)*S(4)).*exp(-(H-S(3)).^2./(2*S(4).^2))+S(5);

end

