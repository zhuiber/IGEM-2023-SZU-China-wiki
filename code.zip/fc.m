function Z = fc(x,y,z)
%x目标对照组的值，一个向量
%y当前对照组的值，一个向量
%z当前实验组的方差，一个向量
beishu = x./y;
Z= beishu.*z;
end

