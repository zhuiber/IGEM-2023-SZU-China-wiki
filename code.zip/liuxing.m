function [RMSE2,Save] = liuxing(x)
y = [0.994000000000000	0.986000000000000	0.966000000000000	0.930000000000000	0.830000000000000	0.764000000000000	0.642000000000000	0.0560000000000000	0.0300000000000000	0.0220000000000000	0];
ops = x(1)*1000;%孢子感染参数1
tau = x(2);%孢子感染增长参数2
alpha = x(3);%孢子传播参数；
n = 51;%指定边界长度
for h = 1:50
    Se = zeros(n);
    z = zeros(n);
    Se(26,26)=1;  %初始化中间的点,1感染 0未感染 2死亡或移除
    %Ch = imagesc(Se);
    %axis square;
    Sd = zeros(n+2);  %边界
    live = zeros(n); %记录发病植株的位置，每生存一个时间单位就+1，当等于3时这株植物就死亡
    s = zeros(n);%孢子浓度矩阵，计算每个位置的累计孢子浓度；
    num = 0;
    save = 0;
    day = x(4);%存活天数
    RMSE1 = 0;
    while(true) %死循环
        save = 0;
        %if num==1 
            %s=zeros(n);end
        for i = 1:n
            for j=1:n
                if live(i,j)<day&&Se(i,j)==1
                    live(i,j)=live(i,j) +1;
                else 
                    if live(i,j)==day
                    Se(i,j) = 2;
                    end
                end
            end
        end
        for i = 1:n%行m,
            for j = 1:n%列 
                if (live(i,j)~=0)&&(live(i,j)~=day)%记录孢子浓度矩阵
                    for  k = 1:n
                        for l = 1:n
                            if k==i&&l==j
                                continue
                            end
                            s(k,l) = s(k,l)+alpha/(sqrt((k-i)^2+(l-j)^2))^x(5);
                        end
                    end
                end
            end    
        end
        p = 1-1./(1+exp((s-ops/1000)/tau));%发病概率矩阵，记录每个位置的发病概率；
        I = rand(n);
        %执行发病指令
        for i = 1:n
            for j = 1:n
                if I(i,j)<=p(i,j)&&Se(i,j)==0
                    Se(i,j)=1;
                    live(i,j) = 1;
                end
            end
        end
        s = zeros(n);
        num=num+1;
        %记录生存个数
        for i=1:n
            for j=1:n 
                if Se(i,j)==0
                    save = save+1;
                end
            end
        end
        Save(h,num) = save/2600;
        %set(Ch,'CData',Se)
        %pause(0.2)
        if num==11
            break;
        end
    end
    Save(h,12) = sqrt(sum((Save(h,[1:11])-y).^2)/11);
end
for i=1:50
    RMSE1 =  RMSE1 + sqrt(sum((Save(i,[1:11])-y).^2)/11);
end
    RMSE2 = RMSE1/50;
